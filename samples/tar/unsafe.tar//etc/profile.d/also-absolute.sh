#!/bin/sh
echo this should not have run
