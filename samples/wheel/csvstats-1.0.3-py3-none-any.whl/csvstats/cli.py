def main():
    print('csvstats')
