class CsvReader:
    pass


class TsvReader:
    pass
