#!/usr/bin/env bash
set -euo pipefail
echo "unpacked $(ls -1 | wc -l) top-level entries"
