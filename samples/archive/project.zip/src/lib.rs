//! A library inside an archive.
pub fn answer() -> u32 {
    42
}
