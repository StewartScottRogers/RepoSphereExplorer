fn main() {
    println!("hello from the archive");
}
