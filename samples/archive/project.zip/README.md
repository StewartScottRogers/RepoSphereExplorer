RepoSphereExplorer sample archive
=================================

This archive exists so the archive plugin has something with structure to
report: nested directories, a mixture of stored and deflated members, a
file large enough to compress well, and one that is already compressed.
